﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test_2
{
    class Program
    {
        static void Main(string[] args)
        {
            bool error=false;// error melting fyrir leikinn
            //birta intro
            Text intro = new Text();
            intro.Test_intro();

            //taka við nafni
            Console.ForegroundColor = ConsoleColor.Magenta;
            Character_info user = new Character_info();
            Console.WriteLine("Hvað heitiru?");
            user.User_Name = Console.ReadLine();

            //taka við Class og byrta stöt með villu meldingu
            do
            {
            
                try
                {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine("Hvað Class viltu vera?\n1.Human\n2.Dwarf\n3.Elf\n4.Troll");
                    user.User_Class = Console.ReadLine();
                    user.Upplysingar_Um_User();
                    error = false;
                }
                catch (ArgumentOutOfRangeException ex)
                {
                
                   Console.WriteLine(ex.Message);
                    error = true;
                }
            } while (error);//error=false

            //fyrsta hæð
           do
            {

                try
                {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Floor1 haed_1 = new Floor1();
                    Console.WriteLine("\nDo you want to enter the tower?? Y/N");
                    haed_1.Room = Console.ReadLine();
                    haed_1.Entering_floor_1();
                    haed_1.Upplysingar_Um_Floor_1();
                    Console.ReadKey();
                }
                catch (ArgumentOutOfRangeException ex_floor_1)
                {

                    Console.WriteLine(ex_floor_1.Message);
                    error = true;
                }
            } while (error);//error=false





           Console.ReadKey();
        }
    }
}
//Birta upplysingar um personu og intro i leikinn line 13-25