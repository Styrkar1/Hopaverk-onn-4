﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test_2
{
    class Text
    {
        private string intro { get; set; }
       
        
        public void Test_intro()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("The Tower Game");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("Eftir ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Styrkár blær");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write(" og ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Magnús orri\n");
        }//introið á leiknu
    }
}
