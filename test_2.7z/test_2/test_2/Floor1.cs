﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test_2
{
    class Floor1
    {
        bool boss = false;// it að sja hvort aðal vondu karlinn er dauðu
        private string room;
        private string move;
        public string Room
        {
            get
            {
                return room;
            }
            set
            {
                if (value == "y")
                {
                    room = "1.3";
                }
                else if (value=="n")
                {
                    room = "Oki see you later then";
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    throw new ArgumentOutOfRangeException("error 002",value,"er ekki valkostur");
                }   
            }

        }// til ad sja i hvada herbegi hann er
        public void Entering_floor_1()
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\nEntering floor 1");
        }//inkoma a fyrstu hæð
        public void Upplysingar_Um_Floor_1()
        {
                Console.ForegroundColor = ConsoleColor.Magenta;
                if (room=="1.3")
                {
                    Console.WriteLine("1.Go south\n2.Go North\n3.Go East");

                }
                

         }

    }
}
