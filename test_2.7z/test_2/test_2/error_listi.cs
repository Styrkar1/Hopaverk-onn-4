﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test_2
{
    class error_listi
    {
        /*
         error 001 
         var vitlaust valið i class menu
          
         error 002
         var vatlaust valið i floor enteri
         
        */
    }
}
