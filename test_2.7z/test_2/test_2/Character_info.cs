﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test_2
{
    class Character_info
    {
        private string user_name;//nafn
        private string user_class;//Class er fyrir hvaða stats hann fær í hverju lvl og byrjar með
        private int user_strength;//hvad hann meiðir mikið
        private int user_vitality;//hvad hann er með goða vörn og lif
        private int user_dexterity;//hversu hratt hann gerir aras
        private int user_inteligant;//fyrir mana
        private int user_hitpoint;//lifið sem hann er með
        private int user_max_hitpoint;//hvad mikið life þu getur haft
        private int user_mana;//mana er til ad nota magic
        private int user_max_mana;//hvad mikið mana þu getur haft
        private int user_lvl;//it lvl gefur boot a stöt eind og atk,def,speed....
        private int user_exp;//it að lvl up
        private int user_max_exp;//hvad mikið exp er i nexta lvl

        public string User_Name
        {
            get
            {
                return user_name;
            }
            set
            {
                user_name = value;
            }
        }//taka við og setja nafn
        public string User_Class//taka við og setja Class
        {
            get
            {
                return user_class;
            }
            set
            {
                if (value == "1")
                {
                    user_class = "Human";
                    byrjunar_Stats();
                }
                else if (value == "2")
                {
                    user_class = "Dwarf";
                    byrjunar_Stats();
                }
                else if (value == "3")
                {
                    user_class = "Elf";
                    byrjunar_Stats();
                }
                else if (value== "4")
                {
                    user_class = "Troll";
                    byrjunar_Stats();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    throw new ArgumentOutOfRangeException("error 001",value,"er ekki valkostur");
                }      
            }
        }

        public void byrjunar_Stats()//byrjynar stöt
        {
            if (user_class=="Human")
            {
                user_strength = 4;
                user_vitality = 2;
                user_dexterity = 2;
                user_inteligant = 2;
                user_max_hitpoint = user_vitality * 10;
                user_hitpoint = 20;
                user_max_mana = user_inteligant * 10;
                user_mana = 20;
                user_lvl = 1;
                user_max_exp = 100;
                user_exp = 0;
            }
            else if (user_class == "Dwarf")
            {
                user_strength = 2;
                user_vitality = 4;
                user_dexterity = 2;
                user_inteligant = 2;
                user_max_hitpoint = user_vitality * 10;
                user_hitpoint = 40;
                user_max_mana = user_inteligant * 10;
                user_mana = 20;
                user_lvl = 1;
                user_max_exp = 100;
                user_exp = 0;
            }
            else if (user_class == "Elf")
            {
                user_strength = 2;
                user_vitality = 2;
                user_dexterity = 4;
                user_inteligant = 2;
                user_max_hitpoint = user_vitality * 10;
                user_hitpoint = 20;
                user_max_mana = user_inteligant * 10;
                user_mana = 20;
                user_lvl = 1;
                user_max_exp = 100;
                user_exp = 0;
            }
            else if (user_class=="Troll")
            {
                user_strength = 2;
                user_vitality = 2;
                user_dexterity = 2;
                user_inteligant = 4;
                user_max_hitpoint = user_vitality * 10;
                user_hitpoint = 20;
                user_max_mana = user_inteligant * 10;
                user_mana = 40;
                user_lvl = 1;
                user_max_exp = 100;
                user_exp = 0;
            }
        }
        public void Upplysingar_Um_User()//birta personu
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("\nName: " + User_Name + "\n");
            Console.Write("Class: " + User_Class + "\n");
            Console.WriteLine("\nStats \nStrength: " + user_strength + "\nVitality: " + user_vitality + "\nDexterity: " + user_dexterity + "\nInteligant: "
            + user_inteligant);
            Console.WriteLine("Level: " + user_lvl + "\nExp: " + user_exp + "/" + user_max_exp + "\nHitpoints: " + user_hitpoint + "/" + user_max_hitpoint +
            "\nMana: " + user_mana + "/" + user_max_mana);
             
        }
    }
}
